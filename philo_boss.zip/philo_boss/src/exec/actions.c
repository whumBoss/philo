 #include "../../header/header.h"
#include <pthread.h>
#include <stdio.h>

//		=== ACTIONS ===

int	print_action(t_philo *philo, char *str)
{
	//assigner data dans data
	t_data	*data;
	long	current_time;
	long	time;

	data = philo->data;

	//verif si le prog dois finir
	if (read_value(&data->lock_end_prog, &data->end_prog))
		return (0);

	//copier le time
	current_time = get_time_of_day();
	time = current_time - data->start_time;

	//ecrire
	pthread_mutex_lock(&data->lock_print);
	printf("%ld : philo %d %s\n", time, philo->id, str);
	pthread_mutex_unlock(&data->lock_print);

	return (1);
}


static int	taking_forks(t_philo *philo)
{
	// recup data
	t_data	*data;

	data = philo->data;
	
	// prendre la fourchette : de droite si c'est un id impair => r (rllr)
	if (philo->id % 2 != 0)
	{
		pthread_mutex_lock(philo->right_fork);
		print_action(philo, "has taken a fork");
	}
	else // de gauche si c'est un id pair => l (lrrl)
	{
		pthread_mutex_lock(philo->left_fork);
		print_action(philo, "has taken a fork");
	}

	// 1 cas speciale
	// il y a un philo et il a pas de fourchette a gauche
	if (!philo->left_fork && data->nb_philo == 1 )
	{
		custom_sleep(data, data->time_die);
		pthread_mutex_lock(&philo->death_lock);
		philo->dead = 1; // Pour indiquer qu'il est mort
		pthread_mutex_unlock(&philo->death_lock);
		pthread_mutex_unlock(philo->right_fork);
		// printf("pas de 2e fourchette\n"); // --> TEST
		return(0);
		// QUESTION : donc il a pas reussis a manger, il a attendus le temps de mourrir, quand est ce qu'il meurs pour de vrai??
	}
	
	// prendre la fourchette : de gauche si c'est un id impair => l (rllr)
	if (philo->id % 2 != 0) 
	{
		pthread_mutex_lock(philo->left_fork);
		print_action(philo, "has taken a fork");
	}
	else // de gauche si c'est un id pair => r (lrrl)
	{
		pthread_mutex_lock(philo->right_fork);
		print_action(philo, "has taken a fork");

	}
	return (1);
	// les fourchettes on bien ete prises
	
	// QUESTION : pas de verif sur les lock des mutex?? on est tjrs sur que c'est ok??
	// QUESTION : ou verif sur l'existance des mutex? deja fait dans le parsing?

}

int	eating(t_philo *philo)
{
	t_data	*data;

	data = philo->data;

	// verif si il faut arreter le prog
	if (read_value(&data->lock_end_prog, &data->end_prog))
		return (0);

	// prendre le fourchettes avec une verif
	if (!taking_forks(philo))
		return (0);
	
	//print l'action dans le terminal
	print_action(philo, "is eating");

	// unknown for now
	update_last_meal(philo);

	// update le nb de meal que le philo a manger
	update_value(&philo->lock_nb_meal_eaten, &philo->nb_meal_eaten);
	//printf("philo %d nb meal eaten %d\n", philo->id, philo->nb_meal_eaten);


	// custom sleep le temps du repas, pour rester lock durant tout ce temps
	custom_sleep(data, data->time_eat);

	// unlock les fourchettes :
	if (philo->id % 2 != 0) // si c'est un id impair (rllr)
	{
		pthread_mutex_unlock(philo->left_fork); // => l
		pthread_mutex_unlock(philo->right_fork); // => r
		//print_action(philo, "unlock the forks"); // --> TEST
	}
	else // si c'est un id pair (lrrl)
	{
		pthread_mutex_unlock(philo->right_fork); // => r
		pthread_mutex_unlock(philo->left_fork); // => l
		//print_action(philo, "unlock the forks"); // --> TEST
	}
	return (1);
}


int	thinking(t_philo *philo)
{
	t_data	*data;
	data = philo->data;
	if (read_value(&data->lock_end_prog, &data->end_prog))
		return (0); // erreur!
	print_action(philo, "is thinking");
	custom_sleep(data, data->time_sleep);
	return (1); // good!
}

int	sleeping(t_philo *philo)
{
	t_data *data;
	data = philo->data;
	if (read_value(&data->lock_end_prog, &data->end_prog))
		return (0); // erreur!
	print_action(philo, "is sleeping");
//	// why on sleep bizzarement???
	if (data->nb_philo % 2 != 0) // si c'eat un nb impair de philo
		custom_sleep(data, 100);
	return (1); // good!

}

