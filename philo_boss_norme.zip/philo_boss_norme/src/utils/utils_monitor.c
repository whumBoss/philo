#include "../../header/header.h"

int	philo_is_dead(t_philo *philo)
{
	if (read_value(&philo->death_lock, &philo->dead))
	{
		print_action(philo, "died");
		return (1);
	}
	return (0);
}

int	philos_finished(t_philo *philo)
{
	t_data	*data;

	data = philo->data;
	return (data->philo_finish_eaten_count == data->nb_philo);
}

int	philo_eaten_all_meal(t_philo *philo)
{
	t_data	*data;

	data = philo->data;
	if (read_value(&philo->lock_nb_meal_eaten, &philo->nb_meal_eaten)
		== data->nb_meal_per_philo && !philo->finished_eaten)
	{
		philo->finished_eaten = 1;
		return (1);
	}
	return (0);
}

long	last_meal_time_ago(t_philo *philo)
{
	long	time;
	t_data	*data;

	data = philo->data;
	time = get_time_of_day() - data->start_time;
	return (time - read_last_meal(philo));
}
